import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StudentGradeCalculator extends JFrame implements ActionListener {
    private JTextField englishField, mathField, scienceField, computerField, historyField;
    private JLabel totalLabel, averageLabel, gradeLabel;
    private JButton calcButton, clearButton;

    public StudentGradeCalculator() {
        setTitle("Student Grade Calculator");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        panel.add(new JLabel("English:"));
        englishField = new JTextField();
        panel.add(englishField);

        panel.add(new JLabel("Math:"));
        mathField = new JTextField();
        panel.add(mathField);

        panel.add(new JLabel("Science:"));
        scienceField = new JTextField();
        panel.add(scienceField);

        panel.add(new JLabel("Computer:"));
        computerField = new JTextField();
        panel.add(computerField);

        panel.add(new JLabel("History:"));
        historyField = new JTextField();
        panel.add(historyField);

        calcButton = new JButton("Calculate Grade");
        calcButton.addActionListener(this);
        panel.add(calcButton);

        clearButton = new JButton("Clear");
        clearButton.addActionListener(this);
        panel.add(clearButton);

        totalLabel = new JLabel("Total Marks: ");
        averageLabel = new JLabel("Average: ");
        gradeLabel = new JLabel("Grade: ");
        panel.add(totalLabel);
        panel.add(new JLabel(""));
        panel.add(averageLabel);
        panel.add(new JLabel(""));
        panel.add(gradeLabel);
        panel.add(new JLabel(""));

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == calcButton) {
            try {
                double eng = Double.parseDouble(englishField.getText());
                double math = Double.parseDouble(mathField.getText());
                double sci = Double.parseDouble(scienceField.getText());
                double comp = Double.parseDouble(computerField.getText());
                double hist = Double.parseDouble(historyField.getText());

                double total = eng + math + sci + comp + hist;
                double average = total / 5;

                String grade;
                if (average >= 90) grade = "A";
                else if (average >= 80) grade = "B";
                else if (average >= 70) grade = "C";
                else if (average >= 60) grade = "D";
                else grade = "F";

                totalLabel.setText("Total Marks: " + total);
                averageLabel.setText(String.format("Average: %.2f", average));
                gradeLabel.setText("Grade: " + grade);

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers for all subjects.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == clearButton) {
            englishField.setText("");
            mathField.setText("");
            scienceField.setText("");
            computerField.setText("");
            historyField.setText("");
            totalLabel.setText("Total Marks: ");
            averageLabel.setText("Average: ");
            gradeLabel.setText("Grade: ");
        }
    }

    public static void main(String[] args) {
        new StudentGradeCalculator();
    }
}
