# 🎓 Student Grade Calculator (Java GUI)

A simple beginner-friendly **Java Swing application** that calculates total marks, average, and grade based on the scores of five subjects.

## 🖥️ Features
- GUI built using **Java Swing**
- Input marks for **English, Math, Science, Computer, and History**
- Automatically calculates:
  - ✅ Total Marks
  - ✅ Average
  - ✅ Grade (A–F)
- Includes **Clear button** to reset fields
- Error handling for invalid inputs

## 🧩 Grade Scale
| Percentage | Grade |
|-------------|--------|
| 90–100 | A |
| 80–89 | B |
| 70–79 | C |
| 60–69 | D |
| Below 60 | F |

## 🏃‍♂️ How to Run
1. Install **Java JDK 8+**
2. Save the file as `StudentGradeCalculator.java`
3. Open terminal/cmd in the file’s directory
4. Compile:
   ```bash
   javac StudentGradeCalculator.java
   ```
5. Run:
   ```bash
   java StudentGradeCalculator
   ```

## 📷 Screenshot
*(You can add your own app screenshot here after running it)*

## 💡 Author
Created by **Piyush Bhadra**  
GitHub: [Your GitHub Username](https://github.com/YourGitHubUsername)

## 🏷️ License
This project is open-source and free to use under the MIT License.
